#include <iostream>
#include <limits> // For input validation
using namespace std;

int currentPlayer;  // Current player (1 or 2)
char currentMarker; // Current player's marker ('X' or 'O')
string player1Name, player2Name; // Player names
char markerP1;
 int slot;
char board[3][3] = { // Initial game grid
    {' ', ' ', ' '},
    {' ', ' ', ' '},
    {' ', ' ', ' '}
};

// Function to display the current state of the board
void displayBoard() {
    cout << "     |     |     " << endl;
    cout << "  " << board[0][0] << "  |  " << board[0][1] << "  |  " << board[0][2] << endl;
    cout << "_____|_____|_____" << endl;
    cout << "     |     |     " << endl;
    cout << "  " << board[1][0] << "  |  " << board[1][1] << "  |  " << board[1][2] << endl;
    cout << "_____|_____|_____" << endl;
    cout << "     |     |     " << endl;
    cout << "  " << board[2][0] << "  |  " << board[2][1] << "  |  " << board[2][2] << endl;
    cout << "     |     |     " << endl;
}

// Function to place the current player's marker on the board at the specified slot
bool placeMarker() {
    int row = (slot - 1) / 3; // Calculate row
    int col = (slot - 1) % 3; // Calculate column
    
    if (board[row][col] == ' ') { // Check if the slot is empty
        board[row][col] = currentMarker; // Place the marker
        return true; // Placement successful
    } else {
        return false; // Slot is already occupied
    }
}

// Function to check if there's a winner
int checkWinner() {
    // Check rows for a win
     for (int i = 0; i < 3; i++){
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ') {
            return currentPlayer; // Current player wins
        }
    }

    // Check columns for a win
     for (int i = 0; i < 3; i++){
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ') {
            return currentPlayer; // Current player wins
        }
    }

    // Check diagonals for a win
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ') {
        return currentPlayer; // Current player wins
    }
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[ 0][2] != ' ') {
        return currentPlayer; // Current player wins
    }

    return 0; // No winner yet
}

// Function to switch players and their markers
void swapPlayerAndMarker() {
    currentMarker = (currentMarker == 'X') ? 'O' : 'X'; // Switch marker
    currentPlayer = (currentPlayer == 1) ? 2 : 1; // Switch player
}

// Main game function that runs the game loop
void game() {
	 

    // Validate marker input
    while (markerP1 != 'X' && markerP1 != 'O') {
        cout << "Invalid marker! Please choose either 'X' or 'O': ";
        cin >> markerP1;
    }
    currentPlayer = 1; // Player 1 starts the game
    currentMarker = markerP1; // Set the current marker to player 1's choice
    int playerWon = 0; // Variable to track the winner (0 if no winner)

    // Loop for up to 9 turns (one for each slot on the board)
    for (int i = 0; i < 9; i++) {
        displayBoard(); // Display the current game board
        cout << "It's player " << (currentPlayer == 1 ? player1Name : player2Name) << "'s turn. Enter your slot (1-9): ";
        // Handle invalid input (non-numeric or out-of-range values)
        while (!(cin >> slot) || slot < 1 || slot > 9) {
            cout << "Invalid input! Please enter a number between 1 and 9." << endl;
		    cin.clear(); // Clear the error flag caused by invalid input
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore any invalid characters left in the input buffer
        }

        // Try placing the current player's marker on the selected slot
        if (!placeMarker()) {
            cout << "Slot is occupied, try again." << endl;
            i--;  // Decrease the turn count to allow the player to try again
            continue;
        }

        // Check if there is a winner after each move
        playerWon = checkWinner();
        if (playerWon == 1) {
            displayBoard(); // Display the final board
            cout << player1Name << " wins!" << endl; // Player 1 wins
            break;
        }
        if (playerWon == 2) {
            displayBoard(); // Display the final board
            cout << player2Name << " wins!" << endl; // Player 2 wins
            break;
        }

        // Switch players after each turn
        swapPlayerAndMarker();
    }

    // If no winner is found after 9 turns, declare a tie
    if (playerWon == 0) {
        displayBoard(); // Display the final board
        cout << "It's a tie!" << endl;
       
    }
}

int main() {
    // Prompt the players for their names
    cout << "Enter name of first player: ";
    cin >> player1Name;
    cout << "Enter name of second player: ";
    cin >> player2Name;

    // Display who is Player 1 and Player 2
    cout << player1Name << " is Player 1, so he/she will play first." << endl;
    cout << player2Name << " is Player 2, so he/she will play second." << endl;
    // Ask player 1 to choose their marker (either 'X' or 'O')
    cout << "Player 1, choose your marker (X or O): ";
    
    cin >> markerP1;
    // Start the game
    game();
     cout<<"GOODBYE :)"<<endl;
    return 0;
}
